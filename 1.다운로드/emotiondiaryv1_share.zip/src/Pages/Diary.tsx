import {useParams, useSearchParams} from "react-router-dom";
import useDiary from "../Hooks/useDiary";
import Button from "../Component/Button";
import Header from "../Component/Header";
import { getFormattedDate } from "../Component/Util";

const Diary = () => {
  const { id } = useParams();
  const data = useDiary(id)
  
  if(!data) {
    return <div>아직 일기를 불러오고 있습니다.</div>;
  } else {
    const {date, emotionId, content} = data;
    const title = `${getFormattedDate(new Date(Number(date)))} 기록`
    return (
      <div>
        <Header
          title={title}
          leftChild={<Button text={"< 뒤로가기"}/>}
          rightChild={<Button text={"수정하기"}/>}
        />
      </div>
    )
  }
}

export default Diary;