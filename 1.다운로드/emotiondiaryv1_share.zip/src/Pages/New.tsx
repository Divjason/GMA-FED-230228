const New = () => {
  return <div>New 페이지입니다.</div>
}

export default New;