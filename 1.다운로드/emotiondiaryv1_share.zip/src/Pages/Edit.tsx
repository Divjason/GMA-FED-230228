const Edit = () => {
  return <div>Edit 페이지입니다.</div>
}

export default Edit;