const num1 = document.querySelector("#number1").value;
const num2 = parseInt(document.querySelector("#number2").value);
const button = document.querySelector("button");
let result = document.querySelector("#result");

button.onclick = () => {
  result.innerText = getGCD(num1, num2);
}

function getGCD(f, s) {
  let max = f > s ? f : s;
  let GCD = 0;
  for (let i = 1; i <= max; i++) {
    if (f % i === 0 && s % i === 0) {
      GCD = i;
    }
  }
  return GCD;
}