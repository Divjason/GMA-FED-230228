import React from 'react';
import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
const API_KEY = process.env.REACT_APP_API_KEY;
const Review = () => {
  const params = useParams();
  console.log('second Params', params);
  const [review, setReview] = useState();
  const getFirstB = () => {
    getReviewApi(params);
  };
  const getReviewApi = async (params) => {
    let url = `https://api.themoviedb.org/3/movie/455476/reviews?api_key=${API_KEY}`;
    let response = await fetch(url);
    let data = await response.json();
    console.log('reviewdata', data);
    setReview(data);
  };
  useEffect(() => {
    getFirstB();
  }, []);
  return (
    <div className="reviewDetail">
      <h1>reviewsdsds</h1>
    </div>
  );
};

export default Review;
