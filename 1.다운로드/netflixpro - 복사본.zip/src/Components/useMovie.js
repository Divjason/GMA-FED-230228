const useMovie = (id) => {
  return '';
};

export default useMovie;
