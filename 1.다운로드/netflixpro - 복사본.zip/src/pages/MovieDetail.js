import React, { useEffect, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faShieldCat } from '@fortawesome/free-solid-svg-icons';
import { faUsers } from '@fortawesome/free-solid-svg-icons';
import { faTv } from '@fortawesome/free-solid-svg-icons';
import { faSoap } from '@fortawesome/free-solid-svg-icons';
import { useParams } from 'react-router-dom';
import { useLocation } from 'react-router-dom';
import { Badge } from 'react-bootstrap';
import { useSelector, useDispatch } from 'react-redux';
import { ClipLoader } from 'react-spinners';
import 'bootstrap/dist/css/bootstrap.min.css';
import { movieAction } from '../redux/actions/movieAction';
import Review from '../Components/Review';

const MovieDetail = () => {
  const dispatch = useDispatch();
  const { popularMovies, topRatedMovies, upComingMovies, loading, genreList } =
    useSelector((state) => state.movie);
  const movieItem = useLocation();
  const movieInfo = movieItem.state.value.item;
  const genres = movieInfo.genre_ids;
  const genreType = movieItem.state.genreContents.genreList;
  const params = useParams();
  console.log(params);
  useEffect(() => {
    dispatch(movieAction.getMovies());
  }, []);
  const API_KEY = process.env.REACT_APP_API_KEY;
  const [review, setReview] = useState();
  const getFirstB = () => {
    getReviewApi(params);
  };
  const getReviewApi = async (params) => {
    let url = `https://api.themoviedb.org/3/movie/${params}/reviews?api_key=${API_KEY}`;
    let response = await fetch(url);
    let data = await response.json();
    console.log('reviewdata', data);
    setReview(data);
  };
  useEffect(() => {
    getFirstB();
  }, []);
  if (loading) {
    return (
      <div className="loader">
        <ClipLoader color="#f00" loading={loading} size={150} />;
      </div>
    );
  }
  return (
    <>
      <div className="Movie-Detail">
        <div className="Movie-Sub">
          <div
            className="posterImg"
            style={{
              backgroundImage:
                'url(' +
                `https://www.themoviedb.org/t/p/w600_and_h900_bestv2${movieInfo.poster_path}` +
                ')',
            }}
          ></div>
          <div className="posterContents">
            <div className="genreType">
              {genres.map((id) => (
                <Badge id="badgeStyle" bg="danger">
                  {genreType.find((item) => item.id === id).name}
                </Badge>
              ))}
            </div>
            <div id="movieTitle">{movieInfo.original_title}</div>
            <div className="movieInfo">
              <div>
                <FontAwesomeIcon
                  id="lineStyle"
                  icon={faShieldCat}
                  style={{ color: 'red' }}
                />
                <span>평점 : {movieInfo.vote_average} 점</span>
              </div>
              <div>
                <FontAwesomeIcon
                  style={{ color: 'red' }}
                  id="lineStyle"
                  icon={faUsers}
                />
                <span>리뷰수 : {movieInfo.popularity} 개</span>
              </div>
              <div>
                <FontAwesomeIcon
                  style={{ color: 'red' }}
                  id="lineStyle"
                  icon={faTv}
                />
                <span>{movieInfo.adult ? '청소년관람불가' : '전체관람가'}</span>
              </div>
            </div>
            <hr />
            <div className="movieStory">{movieInfo.overview}</div>
            <hr />
            <div className="releaseDate">
              <Badge id="badgeStyle" bg="danger">
                Release Day
              </Badge>
              {movieInfo.release_date}
            </div>
            <div className="originalLang">
              <Badge id="badgeStyle" bg="danger">
                Original Language
              </Badge>
              {movieInfo.original_language}
            </div>
            <hr />
            <div>
              <FontAwesomeIcon
                style={{ color: 'red' }}
                id="lineStyle"
                icon={faSoap}
              />
              <span className="watchWord" style={{ color: 'red' }}>
                Watch Trailer
              </span>
            </div>
          </div>
        </div>
        <div className="Movie-Review">
          <div></div>
        </div>
      </div>
      <Review />
    </>
  );
};

export default MovieDetail;
