// let btn = document.querySelector("#submitButton");
// let phoneNum = document.querySelector("#phoneNumberText");

// btn.addEventListener("click", (e) => {
//   e.preventDefault();
//   let phoneNum2 = phoneNum.value;
//   console.log(phoneNum2);
//   let trimmedPhoneNum = phoneNum2.replace(/-/g, "");
//   alert(`전화번호는 ${trimmedPhoneNum} 입니다.`);
// });


document.querySelector("#submitButton").addEventListener("click", (e) => {
  e.preventDefault();
  let phoneNum2 = document.querySelector("#phoneNumberText").value;
  console.log(phoneNum2);
  let trimmedPhoneNum = phoneNum2.replace(/-/g, "");
  alert(`전화번호는 ${trimmedPhoneNum} 입니다.`);
});