//객체 줄임표기법


//구조 분해할당



// let name = person.name;
// let age = person["age"]

let {name, age} = person

let arr = [1, 2, 3, 4];
let [a, b, ...rest] = arr;

let person = {
  name: "park",
  age: 20
}

let person2 = {...person};
let person3 = person;




