import React from 'react';

const Tv = () => {
  return <h1>TV Shows</h1>;
};

export default Tv;
