//Date 객체 => 필터!!!
//pivotDate => 오늘 현시점 날짜 정보
//dateArray => 특정한 날짜가 포함된 배열

function filterThisMonth(pivotDate, dateArray) {
  const year = pivotDate.getFullYear();
  const month = pivotDate.getMonth();

  const startDay = new Date(year, month, 1, 0, 0, 0);
  const endDay = new Date(year, month + 1, 0, 23, 59, 59);

  const resArr = dateArray.filter((it) => 
    startDay.getTime() <= it.getTime() && it.getTime() <= endDay.getTime()
  )
  return resArr;
}

const dateArray = [
  new Date("2023-6-1"),
  new Date("2023-6-30"),
  new Date("2023-7-1"),
  new Date("2023-5-31"),
  new Date("2023-6-22"),
]

const today = new Date("2023-6-22/00:00:00");
const filteredArray = filterThisMonth(today, dateArray);

console.log(filteredArray);