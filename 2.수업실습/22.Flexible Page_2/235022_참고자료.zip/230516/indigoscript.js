function sideMenu() {
  const gnb = document.querySelector(".gnb");
  gnb.classList.toggle("on")
}